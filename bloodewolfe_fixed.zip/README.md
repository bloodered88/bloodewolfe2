# BloodeWolfe App
Prototype d'application P2P de chat vidéo et morpion.

## Déploiement GitHub Pages
1. Crée un dépôt GitHub nommé `bloodewolfe`.
2. Téléverse le contenu de ce dossier **à la racine du dépôt**.
3. Dans `Settings → Pages`, choisis branche `main` et dossier `/root`.
4. Clique `Save` et attends 1 à 5 minutes.
5. Accède à : https://bloodered88.github.io/bloodewolfe
